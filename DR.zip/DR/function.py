
def read_file(file_road):
    list_of_id = []     # 剔除第一项(id)
    list_of_data = []
    with open(file_road, 'r') as input_file:
        count = 0
        lines_1 = input_file.read().split("\n")
        for i in lines_1:
            list_of_new_data = []
            line = i.split(" ")
            for j in line:
                if j == '':
                    continue
                if count == 0:  # 剔除第一项id
                    new_id = int(j)
                    list_of_id.append(new_id)
                else:
                    new_data = float(j)
                    list_of_new_data.append(new_data)
                if count < 99:
                    count += 1
                else:
                    list_of_data.append(list_of_new_data)
                    count = 0
    return list_of_data


def read_file_d(file_road):
    list_of_sex, list_of_age, list_of_race, list_of_face, list_of_prop = [], [], [], [], []
    with open(file_road, 'r') as input_file:
        lines_1 = input_file.read().split("\n")
        for i in lines_1:
            if i == '':
                continue
            # all:2*4*5*3*7
            # 0sex:female->0,male->1    # 77.5
            # 1age:senior->0,adult->1,child->2,teen->3  # 83.7
            # 2race:black->0,white->1,other->2,hispanic->3,asian->4     # 90.4
            # 3face:smiling->0,serious->1,funny->2  # 62.4
            # 4prop:()->0,hat->1,moustache beard->2,moustache->3,beard->4,bandana->5,glasses->6 # 79.7
            if "female" in i:
                list_of_sex.append(0)
            elif "male" in i:
                list_of_sex.append(1)
            if "senior" in i:
                list_of_age.append(0)
            elif "adult" in i:
                list_of_age.append(1)
            elif "child" in i:
                list_of_age.append(2)
            elif "teen" in i:
                list_of_age.append(3)
            else:
                print('age->', i)
            if "black" in i:
                list_of_race.append(0)
            elif "white" in i:
                list_of_race.append(1)
            elif "other" in i:
                list_of_race.append(2)
            elif "hispanic" in i:
                list_of_race.append(3)
            elif "asian" in i:
                list_of_race.append(4)
            else:
                print('race->', i)
            if "smiling" in i:
                list_of_face.append(0)
            elif "serious" in i:
                list_of_face.append(1)
            elif "funny" in i:
                list_of_face.append(2)
            else:
                print('face->', i)
            """
            if "()" in i:
                list_of_prop.append(0)
            elif "hat" in i:
                list_of_prop.append(1)
            elif "moustache beard" in i:
                list_of_prop.append(2)
            elif "moustache" in i:
                list_of_prop.append(3)
            elif "beard" in i:
                list_of_prop.append(4)
            elif "bandana" in i:
                list_of_prop.append(5)
            elif "glasses" in i:
                list_of_prop.append(6)
            else:
                print('prop->', i)
            """
            if "glasses" in i:
                list_of_prop.append(2)
            elif "hat" in i:
                list_of_prop.append(1)
            else:
                list_of_prop.append(0)
    return [list_of_sex, list_of_age, list_of_race, list_of_face, list_of_prop]


if __name__ == '__main__':
    l1 = read_file("data1")
    l2 = read_file_d("faceDR")

