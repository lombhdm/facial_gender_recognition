fid=fopen('rawdata/1256'); 
I = fread(fid);imagesc(reshape(I, 128, 128)'); 
colormap(gray(256));